/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50710
Source Host           : localhost:3306
Source Database       : salesmanagement

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2016-06-15 19:03:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` varchar(32) NOT NULL COMMENT '商品种类id',
  `name` varchar(32) NOT NULL COMMENT '商品种类名称',
  `del_flag` int(1) NOT NULL DEFAULT '0' COMMENT '删除标识{1表示已删除，0表示未删除}'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品种类表';

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('a3efa0816fb14a4787c62a5aa6655590', '零食', '0');
INSERT INTO `category` VALUES ('e509030e84ed4ba9994d7dff4988a020', '饮品', '0');
INSERT INTO `category` VALUES ('753893c896b045a3a18b0f1804039093', '日用品', '0');
INSERT INTO `category` VALUES ('4cd7d2c32bd44fdfbb78902ec647ed5d', '文具', '0');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `name` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `price` decimal(10,2) DEFAULT NULL COMMENT '商品价格',
  `origin` varchar(20) DEFAULT NULL COMMENT '商品产地',
  `stock` double DEFAULT NULL COMMENT '商品库存',
  `warehouse_id` varchar(32) DEFAULT NULL COMMENT '商品所属仓库id',
  `category_id` varchar(32) DEFAULT NULL COMMENT '商品种类id',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标识{1表示已删除，0表示未删除}'
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('51245a3e5ef74f749a09dd69a1276e5a', '可比克薯片', '9.00', '哈尔滨', '245', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '0');
INSERT INTO `goods` VALUES ('12cebd4dda85494099f674641db0d143', '唐僧肉', '3.50', '温州', '133', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '0');
INSERT INTO `goods` VALUES ('8dc70cb890de407999ad13cd275994f1', '老北京鸡爪', '1.50', '福建', '67', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '0');
INSERT INTO `goods` VALUES ('098c3ed447234ebbaf2d39a3f59835f4', '优悦矿泉水', '2.00', '哈尔滨', '190', '4d3bde71480e43d599c436ea673eb964', 'e509030e84ed4ba9994d7dff4988a020', '0');
INSERT INTO `goods` VALUES ('2fa56f90c93e40f6b143e8775205f76a', '康师傅冰红茶（瓶）', '3.00', '长春', '60', '4d3bde71480e43d599c436ea673eb964', 'e509030e84ed4ba9994d7dff4988a020', '0');
INSERT INTO `goods` VALUES ('ebe99d6a1fc449b7a3ab42cbbb045503', '清扬洗发露', '25.00', '北京', '9', '8b4ea76552764374932ea611468bf1a4', '753893c896b045a3a18b0f1804039093', '0');
INSERT INTO `goods` VALUES ('5731efbc2799412a93a59169a9ffcd66', '纳爱斯香皂', '6.50', '上海', '100', '498359201b4f4edbb137a6d0ba82d9b1', '753893c896b045a3a18b0f1804039093', '0');
INSERT INTO `goods` VALUES ('2e70d079865948b89d390c5ac4528cfe', '康师傅红烧牛肉面（袋）', '2.50', '吉林', '1000', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '0');
INSERT INTO `goods` VALUES ('1bca949698144652a0f34bd6259e6bfe', '快客钢笔', '108.00', '北京', '100', '498359201b4f4edbb137a6d0ba82d9b1', '4cd7d2c32bd44fdfbb78902ec647ed5d', '0');
INSERT INTO `goods` VALUES ('9cf1700221da4bcd9a8df0a2788a6c14', '作业本', '1.00', '山西', '1000', '8b4ea76552764374932ea611468bf1a4', '4cd7d2c32bd44fdfbb78902ec647ed5d', '0');
INSERT INTO `goods` VALUES ('bb9fcbd22dc14c7bb35df519cd893165', '陈醋', '25.00', '山西太原', '76', '498359201b4f4edbb137a6d0ba82d9b1', '753893c896b045a3a18b0f1804039093', '0');
INSERT INTO `goods` VALUES ('a983c1bd6e364a4895b79021584acf6c', '一个鸡蛋雪糕（支）', '1.00', '山东', '2000', '4d3bde71480e43d599c436ea673eb964', 'a3efa0816fb14a4787c62a5aa6655590', '0');
INSERT INTO `goods` VALUES ('952a64e8dfd6488cb9eb9d21b16169f5', '晨光签字笔（支）', '3.00', '上海', '10000', '8b4ea76552764374932ea611468bf1a4', '4cd7d2c32bd44fdfbb78902ec647ed5d', '0');
INSERT INTO `goods` VALUES ('fe627e620f804ca8984281da5a3662e7', 'asd', '1123.00', 'asd', '1123', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1');

-- ----------------------------
-- Table structure for sale_order
-- ----------------------------
DROP TABLE IF EXISTS `sale_order`;
CREATE TABLE `sale_order` (
  `id` varchar(32) NOT NULL COMMENT '订单id',
  `bill_no` varchar(20) NOT NULL COMMENT '订单号',
  `handler_id` varchar(32) NOT NULL COMMENT '经手人id',
  `category_id` varchar(32) NOT NULL COMMENT '所属分类id',
  `warehouse_id` varchar(32) NOT NULL COMMENT '所属仓库id',
  `amount` double NOT NULL COMMENT '销售数量',
  `goods_id` varchar(32) NOT NULL COMMENT '商品id',
  `del_flag` int(1) NOT NULL DEFAULT '0' COMMENT '删除标识{1表示已删除，0表示未删除}'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='销售订单表';

-- ----------------------------
-- Records of sale_order
-- ----------------------------
INSERT INTO `sale_order` VALUES ('14801b2d0d7f44ddbf39b31ef6fdc506', '16061511410001', '78d5bc915240430b899527acc55bcf66', 'e509030e84ed4ba9994d7dff4988a020', '4d3bde71480e43d599c436ea673eb964', '10', '098c3ed447234ebbaf2d39a3f59835f4', '0');
INSERT INTO `sale_order` VALUES ('034ae072386f4e619331ee348311fa57', '16061511420001', '78d5bc915240430b899527acc55bcf66', 'e509030e84ed4ba9994d7dff4988a020', '4d3bde71480e43d599c436ea673eb964', '10', '098c3ed447234ebbaf2d39a3f59835f4', '0');
INSERT INTO `sale_order` VALUES ('48020916678a4078b7d8916ca4d1a9a0', '16061511490001', '78d5bc915240430b899527acc55bcf66', '753893c896b045a3a18b0f1804039093', '498359201b4f4edbb137a6d0ba82d9b1', '2', 'bb9fcbd22dc14c7bb35df519cd893165', '0');
INSERT INTO `sale_order` VALUES ('081451903f88435c95992991a8d79ee0', '16061511550001', '78d5bc915240430b899527acc55bcf66', '753893c896b045a3a18b0f1804039093', '498359201b4f4edbb137a6d0ba82d9b1', '2', 'bb9fcbd22dc14c7bb35df519cd893165', '0');
INSERT INTO `sale_order` VALUES ('27922ddf90fe4f85af1f61b9ac998686', '16061513010001', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '1', '51245a3e5ef74f749a09dd69a1276e5a', '0');
INSERT INTO `sale_order` VALUES ('8480b09114f84f88ac13af1bb11583a5', '16061513440001', '2db47a8bc40e4592b7233f7c07453f8b', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '30', '51245a3e5ef74f749a09dd69a1276e5a', '0');
INSERT INTO `sale_order` VALUES ('963a340c38d84f2e8e8b3fe55b818823', '16061513500002', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '3', '8dc70cb890de407999ad13cd275994f1', '0');
INSERT INTO `sale_order` VALUES ('ad4916d66e3344a7ad7dd968d7acc6c4', '16061513590001', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '5', '12cebd4dda85494099f674641db0d143', '0');
INSERT INTO `sale_order` VALUES ('f4ddc233f9344d2cb18c057878f2aafb', '16061516440001', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '5', '8dc70cb890de407999ad13cd275994f1', '0');
INSERT INTO `sale_order` VALUES ('1cc33f4be34c424189fa414664c4a548', '16061517480001', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '9', '12cebd4dda85494099f674641db0d143', '0');
INSERT INTO `sale_order` VALUES ('32106640a0c4473b8419156d2d0b26a6', '16061518070001', '78d5bc915240430b899527acc55bcf66', 'a3efa0816fb14a4787c62a5aa6655590', 'ad2ee5024fde43feb3a26b81190deba8', '1', '12cebd4dda85494099f674641db0d143', '0');

-- ----------------------------
-- Table structure for stock_order
-- ----------------------------
DROP TABLE IF EXISTS `stock_order`;
CREATE TABLE `stock_order` (
  `id` varchar(32) NOT NULL COMMENT 'id',
  `bill_no` varchar(20) NOT NULL COMMENT '订单号',
  `handler_id` varchar(32) NOT NULL COMMENT '经手人id',
  `warehouse_id` varchar(32) NOT NULL COMMENT '商品所属仓库id',
  `category_id` varchar(32) NOT NULL COMMENT '商品所属分类id',
  `amount` double NOT NULL COMMENT '修改数量',
  `goods_id` varchar(32) NOT NULL COMMENT '商品id',
  `sign` int(1) NOT NULL COMMENT '出入库订单区分标识(0表示入库，1表示出库)',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标识{1表示已删除，0表示未删除}'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='出入库订单';

-- ----------------------------
-- Records of stock_order
-- ----------------------------
INSERT INTO `stock_order` VALUES ('9432e438aba147e89c0c9ec3270d2b28', '16061503430001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '100', '51245a3e5ef74f749a09dd69a1276e5a', '0', '0');
INSERT INTO `stock_order` VALUES ('89bd6713ee1f4f91a0cc0f048df38580', '16061503430002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '50', '12cebd4dda85494099f674641db0d143', '0', '0');
INSERT INTO `stock_order` VALUES ('ab85de1de25f47f09a7752cf93005fea', '16061503430003', '78d5bc915240430b899527acc55bcf66', '4d3bde71480e43d599c436ea673eb964', 'a3efa0816fb14a4787c62a5aa6655590', '1000', 'a983c1bd6e364a4895b79021584acf6c', '0', '0');
INSERT INTO `stock_order` VALUES ('203e450b461848daaab762190d22aebf', '16061503430004', '78d5bc915240430b899527acc55bcf66', '4d3bde71480e43d599c436ea673eb964', 'e509030e84ed4ba9994d7dff4988a020', '200', '098c3ed447234ebbaf2d39a3f59835f4', '0', '0');
INSERT INTO `stock_order` VALUES ('fb8144a480b740a791bd772090e828da', '16061504030001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '50', '51245a3e5ef74f749a09dd69a1276e5a', '1', '0');
INSERT INTO `stock_order` VALUES ('ab40b685a3244148bd064fc6a1649c7c', '16061508160001', '78d5bc915240430b899527acc55bcf66', '4d3bde71480e43d599c436ea673eb964', 'e509030e84ed4ba9994d7dff4988a020', '10', '098c3ed447234ebbaf2d39a3f59835f4', '1', '0');
INSERT INTO `stock_order` VALUES ('dde0fbab4d4842308088f77adea657d0', '16061508170001', '78d5bc915240430b899527acc55bcf66', '4d3bde71480e43d599c436ea673eb964', 'e509030e84ed4ba9994d7dff4988a020', '10', '098c3ed447234ebbaf2d39a3f59835f4', '1', '0');
INSERT INTO `stock_order` VALUES ('ab13d1485c5d408a8d69e4625aed77a3', '16061509520001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '10', '8dc70cb890de407999ad13cd275994f1', '1', '0');
INSERT INTO `stock_order` VALUES ('f872620f35fc4097b1cfe8bf8876356b', '16061509530001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '30', '8dc70cb890de407999ad13cd275994f1', '0', '0');
INSERT INTO `stock_order` VALUES ('6f45a6a3b5eb463992ad21ec7f97f4d8', '16061511550002', '78d5bc915240430b899527acc55bcf66', '498359201b4f4edbb137a6d0ba82d9b1', '753893c896b045a3a18b0f1804039093', '2', 'bb9fcbd22dc14c7bb35df519cd893165', '1', '0');
INSERT INTO `stock_order` VALUES ('e45cedc328504f02a90c3fc3494394a7', '16061513010002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1', '51245a3e5ef74f749a09dd69a1276e5a', '1', '1');
INSERT INTO `stock_order` VALUES ('d4e8c8d4798441b194e402b3fcd0aced', '16061513430001', '2db47a8bc40e4592b7233f7c07453f8b', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '25', '51245a3e5ef74f749a09dd69a1276e5a', '0', '0');
INSERT INTO `stock_order` VALUES ('12ec02f2f4ce4e8eb096b0d70a3a4474', '16061513440002', '2db47a8bc40e4592b7233f7c07453f8b', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '30', '51245a3e5ef74f749a09dd69a1276e5a', '1', '0');
INSERT INTO `stock_order` VALUES ('e41ba45b1af0486f8bd3cce2a211e657', '16061513500001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '5', '8dc70cb890de407999ad13cd275994f1', '0', '1');
INSERT INTO `stock_order` VALUES ('b41b821cb7cb4db29137bc0564a088a0', '16061513500003', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '3', '8dc70cb890de407999ad13cd275994f1', '1', '0');
INSERT INTO `stock_order` VALUES ('65f68a9c21c94cb1a6686231d7c6a2fb', '16061513590002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '5', '12cebd4dda85494099f674641db0d143', '1', '0');
INSERT INTO `stock_order` VALUES ('b98fd1145c4d449e8edf7ee4b613907a', '16061516440002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '5', '8dc70cb890de407999ad13cd275994f1', '1', '0');
INSERT INTO `stock_order` VALUES ('afa98b3937e44e3dab8f48ae232c6996', '16061517480002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '9', '12cebd4dda85494099f674641db0d143', '1', '0');
INSERT INTO `stock_order` VALUES ('6b5d610270c0451b8391432de09782f8', '16061517480003', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1', '12cebd4dda85494099f674641db0d143', '1', '0');
INSERT INTO `stock_order` VALUES ('23835ecee6a1496b95d825598a8c8818', '16061517490001', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '10', '51245a3e5ef74f749a09dd69a1276e5a', '0', '0');
INSERT INTO `stock_order` VALUES ('20bfe0a048c648cdbcd03545693dbe62', '16061518070002', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1', '12cebd4dda85494099f674641db0d143', '1', '0');
INSERT INTO `stock_order` VALUES ('604a3a7123c2472dba0669f1d169fa37', '16061518070003', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1', '51245a3e5ef74f749a09dd69a1276e5a', '0', '0');
INSERT INTO `stock_order` VALUES ('2e688d947b1242158c0a0d0ff36d31fa', '16061518070004', '78d5bc915240430b899527acc55bcf66', 'ad2ee5024fde43feb3a26b81190deba8', 'a3efa0816fb14a4787c62a5aa6655590', '1', '12cebd4dda85494099f674641db0d143', '1', '0');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(32) NOT NULL,
  `name` varchar(20) NOT NULL COMMENT '用户名',
  `password` varchar(20) NOT NULL COMMENT '密码',
  `identity` varchar(1) NOT NULL DEFAULT '0' COMMENT '身份标识:0代表普通用户，1代表管理员'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('78d5bc915240430b899527acc55bcf66', 'admin', '123456', '1');
INSERT INTO `user` VALUES ('2db47a8bc40e4592b7233f7c07453f8b', 'lishuai', '123456', '0');

-- ----------------------------
-- Table structure for warehouse
-- ----------------------------
DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE `warehouse` (
  `id` varchar(32) NOT NULL COMMENT '仓库id',
  `name` varchar(20) NOT NULL COMMENT '仓库名称',
  `del_flag` int(1) DEFAULT '0' COMMENT '删除标识{1表示已删除，0表示未删除}',
  `sort` int(10) NOT NULL AUTO_INCREMENT COMMENT '排序规则',
  PRIMARY KEY (`sort`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='仓库表';

-- ----------------------------
-- Records of warehouse
-- ----------------------------
INSERT INTO `warehouse` VALUES ('ad2ee5024fde43feb3a26b81190deba8', '第一仓库', '0', '1');
INSERT INTO `warehouse` VALUES ('4d3bde71480e43d599c436ea673eb964', '第二仓库', '0', '2');
INSERT INTO `warehouse` VALUES ('498359201b4f4edbb137a6d0ba82d9b1', '第三仓库', '0', '3');
INSERT INTO `warehouse` VALUES ('8b4ea76552764374932ea611468bf1a4', '第四仓库', '0', '4');
